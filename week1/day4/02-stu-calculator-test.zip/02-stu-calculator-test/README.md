# Calculator Test

## Instructions

Work in pairs to complete all of the following goals.

Goals:

- Create a class called Calculator.
- In the class, create a method called divide that takes two integers.
- Divide should return the integer that results from dividing the 2 integers.
- It should return 0 if the numerator or denominator is 0.
- Write unit tests to test your divide method.

**Yes, this is bad math, but clients ask for weird things.*

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
