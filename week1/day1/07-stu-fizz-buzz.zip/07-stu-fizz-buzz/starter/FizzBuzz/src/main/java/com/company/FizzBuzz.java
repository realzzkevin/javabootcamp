package com.company;

public class FizzBuzz {
    public static void main(String[] args) {

    }
}
