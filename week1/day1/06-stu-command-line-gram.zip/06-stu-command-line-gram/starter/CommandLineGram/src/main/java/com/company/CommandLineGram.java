package com.company;

public class CommandLineGram {

    public static void main(String[] args) {

    }
}
