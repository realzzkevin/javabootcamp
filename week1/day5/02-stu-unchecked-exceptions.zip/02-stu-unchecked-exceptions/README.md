# Unchecked Exceptions

## Instructions

1. Run the provided starter code using a numeric input. The program should run successfully.
2. Run the provided starter code using a non-numeric input (like your name). The program should NOT run successfully.
3. Using the try/catch syntax that you saw in the first example, try to figure out how to catch this error and print "You must type in a number."

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
