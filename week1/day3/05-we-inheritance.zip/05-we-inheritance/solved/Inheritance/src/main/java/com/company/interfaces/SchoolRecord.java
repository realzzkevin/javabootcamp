package com.company.interfaces;

import com.company.interfaces.Auditable;
import com.company.interfaces.Storable;

public class SchoolRecord implements Storable, Auditable {

    public void storeData() {
        // code here
    }

    public void retrieveData() {
        // code here
    }

    public void runAudit() {
        // code here
    }

    public void sendAuditToState() {
        // code here
    }
}
