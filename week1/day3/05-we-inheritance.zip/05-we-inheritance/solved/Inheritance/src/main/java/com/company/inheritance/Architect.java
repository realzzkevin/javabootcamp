package com.company.inheritance;

public class Architect extends TeamLead {

    public void createTechRoadmap() {
        // code here
    }

    public void evaluateVendor() {

    }
}
