package com.company.interfaces;

public interface Auditable {

    public void runAudit();

    public void sendAuditToState();
}
