package com.company.interfaces;

import com.company.interfaces.SecureStorable;

public class SensitiveDataFile implements SecureStorable {


    public void encryptData() {
        // code here
    }

    public void decryptData() {
        // code here
    }

    public void storeData() {
        // code here
    }

    public void retrieveData() {
        // code here
    }
}
