package com.company.inheritance;

public class App {

    public static void main(String[] args) {
        
    }
}
