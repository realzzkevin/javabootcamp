package com.company.inheritance;

public class Developer {

    public void estimateStoryPoints() {
        // code here
    }

    public void checkInCode() {
        // code here
    }
}
