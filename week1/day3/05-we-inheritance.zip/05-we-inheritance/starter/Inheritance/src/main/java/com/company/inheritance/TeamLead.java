package com.company.inheritance;

public class TeamLead extends Developer {

    public void planSprint() {
        // code here
    }

    public void assignWork(Developer dev) {
        // code here
    }
}
