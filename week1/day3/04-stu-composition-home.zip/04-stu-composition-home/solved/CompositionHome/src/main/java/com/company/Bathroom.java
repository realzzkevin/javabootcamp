package com.company;

public class Bathroom extends Room {
    private String showerType;

    public String getShowerType() {
        return showerType;
    }

    public void setShowerType(String showerType) {
        this.showerType = showerType;
    }
}
