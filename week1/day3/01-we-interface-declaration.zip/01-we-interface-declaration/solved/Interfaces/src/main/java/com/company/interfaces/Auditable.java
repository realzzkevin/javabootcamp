package com.company.interfaces;

public interface Auditable {
    void runAudit();

    void sendAuditToState();
}
