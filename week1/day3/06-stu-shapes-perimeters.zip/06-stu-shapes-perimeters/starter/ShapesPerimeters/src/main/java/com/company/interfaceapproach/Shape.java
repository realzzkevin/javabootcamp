package com.company.interfaceapproach;

public interface Shape {

    public double perimeter();
    public double area();
}
