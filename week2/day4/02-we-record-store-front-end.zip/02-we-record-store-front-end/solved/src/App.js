import Records from './Records.js';

function App() {
  return (
    <main className="container">
      <Records />
    </main>
  );
}

export default App;
