package com.example.helloheroku;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloHerokuApplicationTests {

	@Test
	void contextLoads() {
	}

}
