import Recipes from './Recipes.js';

function App() {
  return (
    <main className="container">
      <Recipes />
    </main>
  );
}

export default App;
