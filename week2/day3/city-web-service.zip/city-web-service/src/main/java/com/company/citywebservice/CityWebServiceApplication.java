package com.company.citywebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CityWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CityWebServiceApplication.class, args);
	}

}
