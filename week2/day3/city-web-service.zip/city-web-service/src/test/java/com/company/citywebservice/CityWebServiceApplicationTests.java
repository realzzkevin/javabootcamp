package com.company.citywebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CityWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
