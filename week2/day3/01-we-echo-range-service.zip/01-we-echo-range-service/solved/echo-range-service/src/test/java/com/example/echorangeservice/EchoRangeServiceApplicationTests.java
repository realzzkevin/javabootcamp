package com.example.echorangeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EchoRangeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
