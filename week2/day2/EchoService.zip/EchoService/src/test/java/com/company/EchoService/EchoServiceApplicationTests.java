package com.company.EchoService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EchoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
