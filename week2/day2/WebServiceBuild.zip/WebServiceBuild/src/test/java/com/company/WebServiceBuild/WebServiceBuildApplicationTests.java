package com.company.WebServiceBuild;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServiceBuildApplicationTests {

	@Test
	void contextLoads() {
	}

}
