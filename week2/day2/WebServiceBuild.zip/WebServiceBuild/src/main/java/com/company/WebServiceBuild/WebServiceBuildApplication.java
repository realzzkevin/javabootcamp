package com.company.WebServiceBuild;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServiceBuildApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServiceBuildApplication.class, args);
	}

}
