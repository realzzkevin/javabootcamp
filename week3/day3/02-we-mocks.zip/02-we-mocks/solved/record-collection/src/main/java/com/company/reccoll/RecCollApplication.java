package com.company.reccoll;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecCollApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecCollApplication.class, args);
	}

}
