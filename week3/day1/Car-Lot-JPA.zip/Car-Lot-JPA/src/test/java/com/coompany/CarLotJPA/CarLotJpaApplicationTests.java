package com.coompany.CarLotJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarLotJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
