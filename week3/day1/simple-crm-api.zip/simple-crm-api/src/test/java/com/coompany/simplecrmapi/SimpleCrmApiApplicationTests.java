package com.coompany.simplecrmapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleCrmApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
