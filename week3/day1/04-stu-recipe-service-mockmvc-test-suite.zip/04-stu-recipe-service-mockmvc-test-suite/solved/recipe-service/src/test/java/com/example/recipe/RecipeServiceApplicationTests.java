package com.example.recipe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
