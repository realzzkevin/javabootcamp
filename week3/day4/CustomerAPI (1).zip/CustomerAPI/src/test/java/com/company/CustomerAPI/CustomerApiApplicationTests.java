package com.company.CustomerAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
