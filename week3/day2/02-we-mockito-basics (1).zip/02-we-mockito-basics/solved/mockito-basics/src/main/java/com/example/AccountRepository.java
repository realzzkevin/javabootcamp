package com.example;

public interface AccountRepository {
    public boolean CreateAccount(String username, String password);
}
