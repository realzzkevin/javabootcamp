package com.example;

public interface FormatChecker {
    public boolean ValidateUsername(String username);
    public boolean ValidatePassword(String password);
}
